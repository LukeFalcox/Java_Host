package com.devfalco.systemNotificacaoAssincrona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemNotificacaoAssincronaApplicationTests {

	@Test
	void contextLoads() {
	}

}
