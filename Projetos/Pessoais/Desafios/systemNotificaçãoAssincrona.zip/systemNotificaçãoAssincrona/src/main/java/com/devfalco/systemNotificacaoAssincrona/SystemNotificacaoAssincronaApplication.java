package com.devfalco.systemNotificacaoAssincrona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemNotificacaoAssincronaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemNotificacaoAssincronaApplication.class, args);
	}

}
